﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebAppModel.DAL;
using WebAppModel.Models;
using WebAppModel.ViewModels;

namespace WebAppModel.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _db;
        public HomeController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {

            List<Student> students = _db.Students.ToList();
            int[] numbers = { 100, 200, 300 };
            string[] groups = { "P116", "P314", "P507", "P213", "P111" };

            HomeVM homeVM = new HomeVM
            {
                Students= students,
                Numbers= numbers,
                Groups= groups
            };

            return View(homeVM);

            //List<Student> students = new List<Student>
            //{
            //    new Student{Id=1,Name="Elgun",Surname="Quluzade"},
            //    new Student{Id=2,Name="Ulvi",Surname="Mecidov"},
            //    new Student{Id=3,Name="Cavid",Surname="Colcemenli"},
            //    new Student{Id=4,Name="Elnur",Surname="Qulamli"},
            //    new Student{Id=5,Name="Hasan",Surname="Hesenbeyli"}
            //};

            //return RedirectToAction("About");
            #region ViewData,Viewbag,TempData
            //ViewData["name"] = "Ulvi";
            //ViewBag.surname = "Mecidov";
            //TempData["age"] = 25;
            #endregion

            #region Return Types
            //return Content();
            //return Json(new { 
            //    name="Ulvi",
            //    surname="Mecidov",
            //    age=25
            //});
            //return File("~/img/001.jpg", "image/jpg");
            #endregion
        }

        public IActionResult About()
        {
            return View();
        }
    }
}