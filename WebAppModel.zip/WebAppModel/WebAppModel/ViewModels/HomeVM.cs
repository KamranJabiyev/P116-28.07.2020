﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAppModel.Models;

namespace WebAppModel.ViewModels
{
    public class HomeVM
    {
        public List<Student> Students { get; set; }
        public int[] Numbers { get; set; }
        public string[] Groups { get; set; }
    }
}
